/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Bahareh
 */
@Entity
@Table(name = "karjoo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Karjoo.findAll", query = "SELECT k FROM Karjoo k"),
    @NamedQuery(name = "Karjoo.findByKarjooID", query = "SELECT k FROM Karjoo k WHERE k.karjooID = :karjooID"),
    @NamedQuery(name = "Karjoo.findByUsername", query = "SELECT k FROM Karjoo k WHERE k.username = :username"),
    @NamedQuery(name = "Karjoo.findByPassword", query = "SELECT k FROM Karjoo k WHERE k.password = :password"),
    @NamedQuery(name = "Karjoo.findByPhone", query = "SELECT k FROM Karjoo k WHERE k.phone = :phone"),
    @NamedQuery(name = "Karjoo.findByMail", query = "SELECT k FROM Karjoo k WHERE k.mail = :mail"),
    @NamedQuery(name = "Karjoo.findBySkype", query = "SELECT k FROM Karjoo k WHERE k.skype = :skype"),
    @NamedQuery(name = "Karjoo.findByFacebook", query = "SELECT k FROM Karjoo k WHERE k.facebook = :facebook"),
    @NamedQuery(name = "Karjoo.findByLinkedin", query = "SELECT k FROM Karjoo k WHERE k.linkedin = :linkedin"),
    @NamedQuery(name = "Karjoo.findByAddress", query = "SELECT k FROM Karjoo k WHERE k.address = :address"),
    @NamedQuery(name = "Karjoo.findByWorkplace", query = "SELECT k FROM Karjoo k WHERE k.workplace = :workplace")})
public class Karjoo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "karjooID")
    private Integer karjooID;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Column(name = "phone")
    private String phone;
    @Column(name = "mail")
    private String mail;
    @Column(name = "skype")
    private String skype;
    @Column(name = "facebook")
    private String facebook;
    @Column(name = "linkedin")
    private String linkedin;
    @Column(name = "address")
    private String address;
    @Column(name = "workplace")
    private String workplace;
    @JoinTable(name = "karjoo_team", joinColumns = {
        @JoinColumn(name = "karjooID", referencedColumnName = "karjooID")}, inverseJoinColumns = {
        @JoinColumn(name = "teamID", referencedColumnName = "teamID")})
    @ManyToMany
    private List<Team> teamList;
    @ManyToMany(mappedBy = "karjooList")
    private List<Project> projectList;
    @ManyToMany(mappedBy = "karjooList")
    private List<Adv> advList;

    public Karjoo() {
    }

    public Karjoo(Integer karjooID) {
        this.karjooID = karjooID;
    }

    public Karjoo(Integer karjooID, String username, String password) {
        this.karjooID = karjooID;
        this.username = username;
        this.password = password;
    }

    public Integer getKarjooID() {
        return karjooID;
    }

    public void setKarjooID(Integer karjooID) {
        this.karjooID = karjooID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getSkype() {
        return skype;
    }

    public void setSkype(String skype) {
        this.skype = skype;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWorkplace() {
        return workplace;
    }

    public void setWorkplace(String workplace) {
        this.workplace = workplace;
    }

    @XmlTransient
    public List<Team> getTeamList() {
        return teamList;
    }

    public void addTeamList(Team team) {
        this.teamList.add(team);
    }

    @XmlTransient
    public List<Project> getProjectList() {
        return projectList;
    }

    public void addProjectList(Project project) {
        this.projectList.add(project);
    }

    @XmlTransient
    public List<Adv> getAdvList() {
        return advList;
    }

    public void addAdvList(Adv adv) {
        this.advList.add(adv);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (karjooID != null ? karjooID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Karjoo)) {
            return false;
        }
        Karjoo other = (Karjoo) object;
        if ((this.karjooID == null && other.karjooID != null) || (this.karjooID != null && !this.karjooID.equals(other.karjooID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Karjoo[ karjooID=" + karjooID + " ]";
    }
    
}
