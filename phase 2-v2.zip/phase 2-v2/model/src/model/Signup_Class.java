/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.List;
import javax.swing.JOptionPane;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.*;
import javax.persistence.Query;
/**
 *
 * @author Bahareh
 */
public class Signup_Class {

    
    private String username;
    private String password;
    private String email;
    private String type;
    public Signup_Class(String username,String password, String email, String type)
    {
        this.username = username;
        this.password = password;
        this.email = email;
        this.type = type;
    }
    public boolean checkAndAdd()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        if(type.equals("karfarma"))
        {
            Query q = em.createQuery("select c from Karfarma c where c.username = :username");
            q.setParameter("username", username);
            List<Karfarma> list = q.getResultList();
            if(list.isEmpty())
            {
                Query q2 = em.createQuery("select c from Karjoo c where c.username = :username");
                q2.setParameter("username", username);
                List<Karjoo> list2 = q2.getResultList();
                if(list2.isEmpty())
                {
                    Karfarma karfarma = new Karfarma();
                    karfarma.setUsername(username);
                    karfarma.setPassword(password);
                    karfarma.setMail(email);
                    karfarma.setAddress(null);
                    karfarma.setHistory(null);
                    karfarma.setManager(null);
                    karfarma.setName(null);
                    karfarma.setPhone(null);
                    karfarma.setPostalCode(null);
                    karfarma.setWebsite(null);
                    em.persist(karfarma);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "این نام کاربری قبلا انتخاب شده است");
                    return false;
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "این نام کاربری قبلا انتخاب شده است");
                return false;
            }
        }
        else 
        {
            Query q = em.createQuery("select c from Karjoo c where c.username = :username");
            q.setParameter("username", username);
            List<Karjoo> list = q.getResultList();
            if(list.isEmpty())
            {
                Query q2 = em.createQuery("select c from Karfarma c where c.username = :username");
                q2.setParameter("username", username);
                List<Karfarma> list2 = q2.getResultList();
                if(list2.isEmpty())
                {
                    Karjoo karjoo = new Karjoo();
                    karjoo.setUsername(username);
                    karjoo.setPassword(password);
                    karjoo.setMail(email);
                    karjoo.setAddress(null);
                    karjoo.setFacebook(null);
                    karjoo.setLinkedin(null);
                    karjoo.setMail(null);
                    karjoo.setPhone(null);
                    karjoo.setSkype(null);
                    karjoo.setWorkplace(null);
                    em.persist(karjoo);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "این نام کاربری قبلا انتخاب شده است");
                    return false;
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "این نام کاربری قبلا انتخاب شده است");
                return false;
            }
        }
    
        em.getTransaction().commit();
        em.close();
        emf.close();   
        return true;
    }

    
    
    
}
