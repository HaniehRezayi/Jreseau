/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Bahareh
 */
@Entity
@Table(name = "karfarma")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Karfarma.findAll", query = "SELECT k FROM Karfarma k"),
    @NamedQuery(name = "Karfarma.findByKarfarmaID", query = "SELECT k FROM Karfarma k WHERE k.karfarmaID = :karfarmaID"),
    @NamedQuery(name = "Karfarma.findByHistory", query = "SELECT k FROM Karfarma k WHERE k.history = :history"),
    @NamedQuery(name = "Karfarma.findByManager", query = "SELECT k FROM Karfarma k WHERE k.manager = :manager"),
    @NamedQuery(name = "Karfarma.findByUsername", query = "SELECT k FROM Karfarma k WHERE k.username = :username"),
    @NamedQuery(name = "Karfarma.findByPassword", query = "SELECT k FROM Karfarma k WHERE k.password = :password"),
    @NamedQuery(name = "Karfarma.findByName", query = "SELECT k FROM Karfarma k WHERE k.name = :name"),
    @NamedQuery(name = "Karfarma.findByPhone", query = "SELECT k FROM Karfarma k WHERE k.phone = :phone"),
    @NamedQuery(name = "Karfarma.findByMail", query = "SELECT k FROM Karfarma k WHERE k.mail = :mail"),
    @NamedQuery(name = "Karfarma.findByWebsite", query = "SELECT k FROM Karfarma k WHERE k.website = :website"),
    @NamedQuery(name = "Karfarma.findByPostalCode", query = "SELECT k FROM Karfarma k WHERE k.postalCode = :postalCode"),
    @NamedQuery(name = "Karfarma.findByAddress", query = "SELECT k FROM Karfarma k WHERE k.address = :address")})
public class Karfarma implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "karfarmaID")
    private Integer karfarmaID;
    @Column(name = "history")
    private String history;
    @Column(name = "manager")
    private String manager;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Column(name = "name")
    private String name;
    @Column(name = "phone")
    private String phone;
    @Column(name = "mail")
    private String mail;
    @Column(name = "website")
    private String website;
    @Column(name = "postalCode")
    private String postalCode;
    @Column(name = "address")
    private String address;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "karfarmaID")
    private List<Adv> advList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "karfarmaID")
    private List<Project> projectList;

    public Karfarma() {
    }

    public Karfarma(Integer karfarmaID) {
        this.karfarmaID = karfarmaID;
    }

    public Karfarma(Integer karfarmaID, String username, String password) {
        this.karfarmaID = karfarmaID;
        this.username = username;
        this.password = password;
    }

    public Integer getKarfarmaID() {
        return karfarmaID;
    }

    public void setKarfarmaID(Integer karfarmaID) {
        this.karfarmaID = karfarmaID;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlTransient
    public List<Adv> getAdvList() {
        return advList;
    }

    public void addAdvList(Adv adv) {
        this.advList.add(adv);
    }

    @XmlTransient
    public List<Project> getProjectList() {
        return projectList;
    }

    public void addProjectList(Project project) {
        this.projectList.add(project);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (karfarmaID != null ? karfarmaID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Karfarma)) {
            return false;
        }
        Karfarma other = (Karfarma) object;
        if ((this.karfarmaID == null && other.karfarmaID != null) || (this.karfarmaID != null && !this.karfarmaID.equals(other.karfarmaID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Karfarma[ karfarmaID=" + karfarmaID + " ]";
    }
    
}
