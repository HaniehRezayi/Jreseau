/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import com.sun.accessibility.internal.resources.accessibility;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;

/**
 *
 * @author Bahareh
 */
public class Update_Karfarma_Class {
    
    private String name;
    private String phone;
    private String email;
    private String website;
    private String postalCode;
    private String address;
    private String username;
    private String history;
    private String manager;
    private String password;
    private List<Project> projects;
    private List<Adv> advertisements;
    public Update_Karfarma_Class()
    {
    }
    public void set_name(String str)
    {this.name = str;}
    public void set_phone(String str)
    {this.phone = str;}
    public void set_email(String str)
    {this.email = str;}
    public void set_website(String str)
    {this.website = str;}
    public void set_postalcode(String str)
    {this.postalCode = str;}
    public void set_address(String str)
    {this.address = str;}
    public void set_username(String str)
    {this.username = str;}
    public void set_history(String str)
    {this.history = str;}
    public void set_manager(String str)
    {this.manager = str;}
    public void set_password(String str)
    {this.password = str;}
    
    public String get_name()
    {return name;}
    public String get_username()
    {return username;}
    public String get_password()
    {return password;}
    public String get_manager()
    {return manager;}
    public String get_history()
    {return history;}
    public String get_phone()
    {return phone;}
    public String get_email()
    {return email;}
    public String get_postalcode()
    {return postalCode;}
    public String get_address()
    {return address;}
    public String get_website()
    {return website;}
    public List<Project> get_projects()
    {return projects;}
    public List<Adv> get_advs()
    {return advertisements;}
    public void setAdvsList(List<Adv> adv)
    {this.advertisements = adv;}
    public void setProjectList(List<Project> projects)
    {this.projects = projects;}
    public void add_advertisement(String name, String  explanation,String salary, String type, String skills)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karfarma c where c.username = :username"); 
        q.setParameter("username", this.username);
        List<Karfarma> list_karfarma = q.getResultList();
        
        Adv adv = new Adv();
        adv.setExplanation(explanation);
        adv.setSalary(salary);
        adv.setSkills(skills);
        adv.setTitle(name);
        adv.setType(type);
        adv.setKarfarmaID(list_karfarma.get(0));
        list_karfarma.get(0).addAdvList(adv);
        
        advertisements.add(adv);
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
    public boolean add_project(String projectName, String projectExplanation, String projectStartDate, 
            String projectEnddate, String projectManager, String projectPeople)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        //checking if the manager exits in the database
        Query q = em.createQuery("select c from Karjoo c where c.username = :username"); 
        q.setParameter("username", manager);
        List<Karjoo> karjoo_manager = q.getResultList();
        if(karjoo_manager.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "نام کاربری مدیر پروژه یافت نشد");
            return false;
        }
        // checking if the people mentioned in the project exist in the database
        String[] people = projectPeople.split("-");
        List<Karjoo> karjoo_people=  q.getResultList();
        for(int i=0; i<people.length; i++)
        {
            q = em.createQuery("select c from Karjoo c where c.username = :username"); 
            q.setParameter("username", people[i]);
            karjoo_people = q.getResultList();
            if(karjoo_people.isEmpty())
            {
                JOptionPane.showMessageDialog(null, "یافت نشد "+people[i] + "نام کاربری ");
                return false;
            }
        }
        //we now can add the project successfully!
        Project project = new Project();
        project.setEnddate(projectEnddate);
        project.setName(projectName);
        project.setStartdate(projectStartDate);
        project.setManager(projectManager);
        q = em.createQuery("select c from Karfarma c where c.username = :username"); 
        q.setParameter("username", this.username);
        List<Karfarma> list_karfarma = q.getResultList();
        project.setKarfarmaID(list_karfarma.get(0));
        project.setKarjooList(karjoo_people);
        projects.add(project);
        list_karfarma.get(0).addProjectList(project);
        
        em.getTransaction().commit();
        em.close();
        emf.close();
        return true;
    }
    public void update_contact()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karfarma c where c.username = :username");
        q.setParameter("username", username);
        List<Karfarma> list = q.getResultList();
        
        list.get(0).setName(name);
        list.get(0).setMail(email);
        list.get(0).setWebsite(website);
        list.get(0).setPostalCode(postalCode);
        list.get(0).setAddress(address);
        list.get(0).setPhone(phone);
        
        em.getTransaction().commit();
        em.close();
        emf.close();  
    }
    public void update_about()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karfarma c where c.username = :username");
        q.setParameter("username", username);
        
        List<Karfarma> list = q.getResultList();
        list.get(0).setHistory(history);
        list.get(0).setManager(manager);
        
        em.getTransaction().commit();
        em.close();
        emf.close();  
    }
}
