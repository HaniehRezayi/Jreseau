package model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Bahareh
 */

public class Login_Class {
    
    
    String user;
    String pass;
    
    public Login_Class(String username,String password)
    {
        user=username;
        pass=password;
    }
    
    public boolean Check()
    {
        if(user.equalsIgnoreCase("bahareh") && pass.equalsIgnoreCase("bahareh"))
        {
            return true;
        }
        return false;
    }
    
    public String get_username()
    {
        return user;
    }
}
