package model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Bahareh
 */

public class login_class {
    
    
    String username;
    String password;
    
    public login_class(String username,String password)
    {
        this.username=username;
        this.password=password;
    }
    
    public boolean Check()
    {
        if(username.equalsIgnoreCase("karfarma") && password.equalsIgnoreCase("karfarma"))
        {
            return true;
        }
        return false;
    }
    
    public String get_username()
    {
        return username;
    }
}
