/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.swing.JOptionPane;

/**
 *
 * @author Bahareh
 */
public class Signup_Class {

    String user;
    String pass;
    String mail;
    
    public Signup_Class(String username,String password, String email, String password_conf)
    {
        user = username;
        pass = password;
        mail = email;
        
    }
    
    
    
}
