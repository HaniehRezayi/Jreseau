/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;

/**
 *
 * @author Bahareh
 */
public class Update_Karjoo_Class {
    private String username;
    private String password;
    private String phone;
    private String name;
    private String birthday;
    private String mail;
    private String skype;
    private String facebook;
    private String linkedin;
    private String address;
    private String workplace;
    private String resume;
    private String resume_date;
    private String skills;
    private List<Project> projects;
    private List<Adv> ads;
    
    public Update_Karjoo_Class()
    {
    }
    public String get_username()
    {return username;}
    public String get_name()
    {return name;}
    public String get_birthday()
    {return birthday;}
    public String get_password()
    {return password;}
    public String get_phone()
    {return phone;}
    public String get_mail()
    {return mail;}
    public String get_skype()
    {return skype;}
    public String get_linkedin()
    {return linkedin;}
    public String get_facebook()
    {return facebook;}
    public String get_address()
    {return address;}
    public String get_workplace()
    {return workplace;}
    public String get_resume()
    {return resume;}
    public String get_skills()
    {return skills;}
    public String get_resumeDate()
    {return resume_date;}
    public List<Project> get_projects()
    {return projects;}
    public List<Adv> get_ads()
    {return ads;}
    
    public void set_username(String username)
    {this.username = username;}
    public void set_password(String password)
    {this.password = password;}
    public void set_facebook(String facebook)
    {this.facebook = facebook;}
    public void set_linkedin(String linkedin)
    {this.linkedin = linkedin;}
    public void set_mail(String mail)
    {this.mail = mail;}
    public void set_skype(String skype)
    {this.skype = skype;}
    public void set_address(String address)
    {this.address = address;}
    public void set_workplace(String workplace)
    {this.workplace = workplace;}
    public void set_resume(String resume)
    {this.resume = resume;}
    public void set_skills(String skills)
    {this.skills = skills;}
    public void set_phone(String phone)
    {this.phone = phone;}
    public void set_name(String name)
    {this.name = name;}
    public void set_birthday(String birthday)
    {this.birthday = birthday;}
    public void set_resumeDate(String resume_date)
    {this.resume_date = resume_date;}
    public void set_projects(List<Project> projects)
    {this.projects = projects;}
    public void add_ad(String ad_title)
    {
        Adv ad = null;
        for(int i=0; i<ads.size(); i++)
        {
            if(ads.get(i).getTitle().equals(ad_title))
            {
              ad = ads.get(i);  
            }
        }
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Query q = em.createQuery("select c from Adv c where c.title = :title");
        q.setParameter("title", ad.getTitle());
        List<Adv> list_ad = q.getResultList();
        
        Query q2 = em.createQuery("select c from Karjoo c where c.username = :username");
        q.setParameter("username", username);
        List<Karjoo> list_karjoo = q2.getResultList();
        
        list_ad.get(0).addKarjooList(list_karjoo.get(0));
        list_karjoo.get(0).addAdvList(ad);
        
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
    public List<Adv> search_ads(String skills, String salary, String keyWords)
    {
        String[] skills_array = skills.split("-");
        String[] keyWords_array = keyWords.split("-");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Adv c where c.salary = :salary");
        q.setParameter("salary", salary);
        List<Adv> list = q.getResultList();
        if(list.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "هیچ آگهی شامل این حقوق نیست");
            ads=list;
            return null;
        }
        for(int i=0; i<list.size(); i++)
        {
            String[] skills_adv = list.get(i).getSkills().split("-");
            for(int j=0; j<skills_array.length; j++)
            {
                boolean flag = false;
                for(int k=0; i<skills_adv.length; k++)
                {
                    if(skills_adv[k]==skills_array[j])
                    {
                        flag=true;
                        break;
                    }
                }
                if(flag==false)
                {
                    list.remove(i);
                    i--;
                    break;
                }
            }
        }
        if(list.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "هیچ آگهی شامل تمام مهارت ها نیست");
            ads=list;        
            return null;
        }
        for(int i=0; i<list.size(); i++)
        {
            String[] keywords_adv = list.get(i).getExplanation().split(" ");
            for(int j=0; j<keyWords_array.length; j++)
            {
                boolean flag = false;
                for(int k=0; i<keywords_adv.length; k++)
                {
                    if(keywords_adv[k]==keyWords_array[j])
                    {
                        flag=true;
                        break;
                    }
                }
                if(flag==false)
                {
                    list.remove(i);
                    i--;
                    break;
                }
            }
        }
        if(list.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "هیچ آگهی شامل تمام کلمات کلیدی نیست");
            ads=list;
            return null;
        }
        em.getTransaction().commit();
        em.close();
        emf.close();
        ads=list;
        return list;
    }        
    public void update_resume()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karjoo c where c.username = :username");
        q.setParameter("username", username);
        List<Karjoo> list = q.getResultList();
        
        list.get(0).setResume(resume);
        list.get(0).setResumeDate(resume_date);
        
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
    public void update_contact()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karjoo c where c.username = :username");
        q.setParameter("username", username);
        List<Karjoo> list = q.getResultList();
        
        list.get(0).setAddress(address);
        list.get(0).setFacebook(facebook);
        list.get(0).setLinkedin(linkedin);
        list.get(0).setMail(mail);
        list.get(0).setSkype(skype);
        list.get(0).setPhone(phone);
        
        em.getTransaction().commit();
        em.close();
        emf.close();  
    }
    public void update_about()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karjoo c where c.username = :username");
        q.setParameter("username", username);
        
        List<Karjoo> list = q.getResultList();
        list.get(0).setName(name);
        list.get(0).setWorkplace(workplace);
        list.get(0).setSkills(skills);
        em.getTransaction().commit();
        em.close();
        emf.close();  
    }
}
