package model;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Bahareh
 */

public class Login_Class {
    
    
    String user;
    String pass;
    Update_Karfarma_Class update_karfarma_class;
    Update_Karjoo_Class update_karjoo_class;
    public Login_Class(String username,String password)
    {
        user=username;
        pass=password;
    }
    public Update_Karfarma_Class get_karfarma()
    {return update_karfarma_class;}
    public Update_Karjoo_Class get_karjoo()
    {return update_karjoo_class;}
    
    public int Check()
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("modelPU");
        //JOptionPane.showMessageDialog(null, "here!");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        
        Query q = em.createQuery("select c from Karfarma c where c.username = :username");
        q.setParameter("username", user);
        List<Karfarma> list = q.getResultList();
        if(list.isEmpty()==false)   //karfarma
        {
            for(int i=0; i<list.size(); i++)
            {
                if(list.get(i).getPassword().equals(pass))
                {
                    update_karfarma_class = new Update_Karfarma_Class();
                    update_karfarma_class.set_username(user);
                    update_karfarma_class.set_password(pass);
                    update_karfarma_class.set_address(list.get(i).getAddress());
                    update_karfarma_class.set_email(list.get(i).getMail());
                    update_karfarma_class.set_history(list.get(i).getHistory());
                    update_karfarma_class.set_manager(list.get(i).getManager());
                    update_karfarma_class.set_name(list.get(i).getName());
                    update_karfarma_class.set_phone(list.get(i).getPhone());
                    update_karfarma_class.set_postalcode(list.get(i).getPostalCode());
                    update_karfarma_class.set_website(list.get(i).getWebsite());
                    update_karfarma_class.setAdvsList(list.get(i).getAdvList());
                    update_karfarma_class.setProjectList(list.get(i).getProjectList());
                    return 1;
                }
            }
        }
        
        Query q2 = em.createQuery("select c from Karjoo c where c.username = :username");
        q2.setParameter("username", user);
        List<Karjoo> list2 = q2.getResultList();
        if(list2.isEmpty()==false)      //karjoo
        {
            for(int i=0; i<list2.size(); i++)
                if(list2.get(i).getPassword().equals(pass))
                {
                    
                    update_karjoo_class = new Update_Karjoo_Class();
                    update_karjoo_class.set_address(list2.get(i).getAddress());
                    update_karjoo_class.set_facebook(list2.get(i).getFacebook());
                    update_karjoo_class.set_linkedin(list2.get(i).getLinkedin());
                    update_karjoo_class.set_mail(list2.get(i).getMail());
                    update_karjoo_class.set_password(pass);
                    update_karjoo_class.set_phone(list2.get(i).getPhone());
                    update_karjoo_class.set_resume(list2.get(i).getResume());
                    update_karjoo_class.set_skills(list2.get(i).getSkills());
                    update_karjoo_class.set_skype(list2.get(i).getSkype());
                    update_karjoo_class.set_username(user);
                    update_karjoo_class.set_workplace(list2.get(i).getWorkplace());
                    update_karjoo_class.set_projects(list2.get(i).getProjectList());
                    return 2;
                }
        }
        return 0;
    
    }
}