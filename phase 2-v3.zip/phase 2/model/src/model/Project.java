/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Bahareh
 */
@Entity
@Table(name = "project")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Project.findAll", query = "SELECT p FROM Project p"),
    @NamedQuery(name = "Project.findByProjectID", query = "SELECT p FROM Project p WHERE p.projectID = :projectID"),
    @NamedQuery(name = "Project.findByName", query = "SELECT p FROM Project p WHERE p.name = :name"),
    @NamedQuery(name = "Project.findByStartdate", query = "SELECT p FROM Project p WHERE p.startdate = :startdate"),
    @NamedQuery(name = "Project.findByEnddate", query = "SELECT p FROM Project p WHERE p.enddate = :enddate"),
    @NamedQuery(name = "Project.findByManager", query = "SELECT p FROM Project p WHERE p.manager = :manager"),
    @NamedQuery(name = "Project.findByExplanation", query = "SELECT p FROM Project p WHERE p.explanation = :explanation")})
public class Project implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "projectID")
    private Integer projectID;
    @Column(name = "name")
    private String name;
    @Column(name = "startdate")
    private String startdate;
    @Column(name = "enddate")
    private String enddate;
    @Column(name = "manager")
    private String manager;
    @Basic(optional = false)
    @Column(name = "explanation")
    private String explanation;
    @JoinTable(name = "project_karjoo", joinColumns = {
        @JoinColumn(name = "projectID", referencedColumnName = "projectID")}, inverseJoinColumns = {
        @JoinColumn(name = "karjooID", referencedColumnName = "karjooID")})
    @ManyToMany
    private List<Karjoo> karjooList;
    @JoinColumn(name = "karfarmaID", referencedColumnName = "karfarmaID")
    @ManyToOne(optional = false)
    private Karfarma karfarmaID;
    @JoinColumn(name = "teamID", referencedColumnName = "teamID")
    @ManyToOne
    private Team teamID;

    public Project() {
    }

    public Project(Integer projectID) {
        this.projectID = projectID;
    }

    public Project(Integer projectID, String explanation) {
        this.projectID = projectID;
        this.explanation = explanation;
    }

    public Integer getProjectID() {
        return projectID;
    }

    public void setProjectID(Integer projectID) {
        this.projectID = projectID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    @XmlTransient
    public List<Karjoo> getKarjooList() {
        return karjooList;
    }

    public void setKarjooList(List<Karjoo> karjoo) {
        this.karjooList = karjoo;
    }

    public Karfarma getKarfarmaID() {
        return karfarmaID;
    }

    public void setKarfarmaID(Karfarma karfarmaID) {
        this.karfarmaID = karfarmaID;
    }

    public Team getTeamID() {
        return teamID;
    }

    public void setTeamID(Team teamID) {
        this.teamID = teamID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (projectID != null ? projectID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Project)) {
            return false;
        }
        Project other = (Project) object;
        if ((this.projectID == null && other.projectID != null) || (this.projectID != null && !this.projectID.equals(other.projectID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Project[ projectID=" + projectID + " ]";
    }
    
}
