/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Bahareh
 */
@Entity
@Table(name = "adv")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Adv.findAll", query = "SELECT a FROM Adv a"),
    @NamedQuery(name = "Adv.findByAdvID", query = "SELECT a FROM Adv a WHERE a.advID = :advID"),
    @NamedQuery(name = "Adv.findByTitle", query = "SELECT a FROM Adv a WHERE a.title = :title"),
    @NamedQuery(name = "Adv.findBySalary", query = "SELECT a FROM Adv a WHERE a.salary = :salary"),
    @NamedQuery(name = "Adv.findByType", query = "SELECT a FROM Adv a WHERE a.type = :type"),
    @NamedQuery(name = "Adv.findBySkills", query = "SELECT a FROM Adv a WHERE a.skills = :skills"),
    @NamedQuery(name = "Adv.findByExplanation", query = "SELECT a FROM Adv a WHERE a.explanation = :explanation"),
    @NamedQuery(name = "Adv.findByDate", query = "SELECT a FROM Adv a WHERE a.date = :date")})
public class Adv implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "advID")
    private Integer advID;
    @Column(name = "title")
    private String title;
    @Column(name = "salary")
    private String salary;
    @Column(name = "type")
    private String type;
    @Column(name = "skills")
    private String skills;
    @Column(name = "explanation")
    private String explanation;
    @Column(name = "date")
    private String date;
    @JoinTable(name = "adv_team", joinColumns = {
        @JoinColumn(name = "advID", referencedColumnName = "advID")}, inverseJoinColumns = {
        @JoinColumn(name = "teamID", referencedColumnName = "teamID")})
    @ManyToMany
    private List<Team> teamList;
    @JoinTable(name = "adv_karjoo", joinColumns = {
        @JoinColumn(name = "advID", referencedColumnName = "advID")}, inverseJoinColumns = {
        @JoinColumn(name = "karjooID", referencedColumnName = "karjooID")})
    @ManyToMany
    private List<Karjoo> karjooList;
    @JoinColumn(name = "karfarmaID", referencedColumnName = "karfarmaID")
    @ManyToOne(optional = false)
    private Karfarma karfarmaID;

    public Adv() {
    }

    public Adv(Integer advID) {
        this.advID = advID;
    }

    public Integer getAdvID() {
        return advID;
    }

    public void setAdvID(Integer advID) {
        this.advID = advID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @XmlTransient
    public List<Team> getTeamList() {
        return teamList;
    }

    public void addTeamList(Team team) {
        this.teamList.add(team);
    }

    @XmlTransient
    public List<Karjoo> getKarjooList() {
        return karjooList;
    }

    public void addKarjooList(Karjoo karjoo) {
        this.karjooList.add(karjoo);
    }

    public Karfarma getKarfarmaID() {
        return karfarmaID;
    }

    public void setKarfarmaID(Karfarma karfarmaID) {
        this.karfarmaID = karfarmaID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (advID != null ? advID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Adv)) {
            return false;
        }
        Adv other = (Adv) object;
        if ((this.advID == null && other.advID != null) || (this.advID != null && !this.advID.equals(other.advID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Adv[ advID=" + advID + " ]";
    }
    
}
