/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Bahareh
 */
@Entity
@Table(name = "team")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Team.findAll", query = "SELECT t FROM Team t"),
    @NamedQuery(name = "Team.findByTeamID", query = "SELECT t FROM Team t WHERE t.teamID = :teamID"),
    @NamedQuery(name = "Team.findByUsername", query = "SELECT t FROM Team t WHERE t.username = :username")})
public class Team implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "teamID")
    private Integer teamID;
    @Column(name = "username")
    private String username;
    @ManyToMany(mappedBy = "teamList")
    private List<Karjoo> karjooList;
    @ManyToMany(mappedBy = "teamList")
    private List<Adv> advList;
    @OneToMany(mappedBy = "teamID")
    private List<Project> projectList;

    public Team() {
    }

    public Team(Integer teamID) {
        this.teamID = teamID;
    }

    public Integer getTeamID() {
        return teamID;
    }

    public void setTeamID(Integer teamID) {
        this.teamID = teamID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @XmlTransient
    public List<Karjoo> getKarjooList() {
        return karjooList;
    }

    public void addKarjooList(Karjoo karjoo) {
        this.karjooList.add(karjoo);
    }

    @XmlTransient
    public List<Adv> getAdvList() {
        return advList;
    }

    public void addAdvList(Adv adv) {
        this.advList.add(adv);
    }

    @XmlTransient
    public List<Project> getProjectList() {
        return projectList;
    }

    public void addProjectList(Project project) {
        this.projectList.add(project);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (teamID != null ? teamID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Team)) {
            return false;
        }
        Team other = (Team) object;
        if ((this.teamID == null && other.teamID != null) || (this.teamID != null && !this.teamID.equals(other.teamID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Team[ teamID=" + teamID + " ]";
    }
    
}
