/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.*;
import java.util.*;

 
/**
 *
 * @author Bahareh
 */
public class Model {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("karfarmas2.odb");
        EntityManager em = emf.createEntityManager();
 
        // Store 1000 Point objects in the database:
        em.getTransaction().begin();
        for (int i = 0; i < 1000; i++) {
            Karfarma p = new Karfarma("karfarma", "karfarma");
            em.persist(p);
        }
        em.getTransaction().commit();
 
        // Find the number of Point objects in the database:
        Query q1 = em.createQuery("SELECT COUNT(p) FROM Karfarma p");
        System.out.println("Total Points: " + q1.getSingleResult());
 
        // Find the average X value:
        //Query q2 = em.createQuery("SELECT AVG(p.x) FROM Karfarma p");
        //System.out.println("Average X: " + q2.getSingleResult());
 
        // Retrieve all the Point objects from the database:
        TypedQuery<Karfarma> query =
            em.createQuery("SELECT p FROM Karfarma p", Karfarma.class);
        List<Karfarma> results = query.getResultList();
        for (Karfarma p : results) {
            System.out.println(p);
        }
 
        // Close the database connection:
        em.close();
        emf.close();
        */
    }
    
}
