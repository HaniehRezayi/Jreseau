/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Update_Karfarma_Class;
import model.Update_Karjoo_Class;

/**
 *
 * @author Bahareh
 */
@WebServlet(urlPatterns = {"/About_Create_Karjoo_Servlet"})
public class About_Create_Karjoo_Servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet About_Create_Karjoo_Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet About_Create_Karjoo_Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = (String) request.getParameter("name");
        String workplace = (String) request.getParameter("workplace");
        String skills = (String) request.getParameter("skills");
        String birthday = (String) request.getParameter("birthday");
        HttpSession httpSession = request.getSession(true);
        Update_Karjoo_Class update_karjoo_class = (Update_Karjoo_Class) httpSession.getAttribute("update_karjoo_class");
        
        update_karjoo_class.set_name(name);
        update_karjoo_class.set_workplace(workplace);
        update_karjoo_class.set_skills(skills);
        update_karjoo_class.set_birthday(birthday);
        update_karjoo_class.update_about();
        httpSession.setAttribute("update_karjoo_class", update_karjoo_class);        
        
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("/about_karjoo.jsp");
        if(requestDispatcher!= null)
            requestDispatcher.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
