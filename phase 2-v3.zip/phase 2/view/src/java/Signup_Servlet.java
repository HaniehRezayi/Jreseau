/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import model.Signup_Class;
import javax.persistence.*;
/**
 *
 * @author Bahareh
 */
@WebServlet(urlPatterns = {"/Signup_Servlet"})
public class Signup_Servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Signup_Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Signup_Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = (String) request.getParameter("username");
        String email = (String) request.getParameter("email");
        String password = (String) request.getParameter("password");
        String password_confirm = (String) request.getParameter("password_confirm");
        String type = (String) request.getParameter("type");
        if(username!=null && email!=null && password!=null && password_confirm!=null)
        {
            if(password.equals(password_confirm))
            {
                Signup_Class signup_class = new Signup_Class(username, password, email, type);
                if(signup_class.checkAndAdd())
                {
                    request.setAttribute("signup_class", signup_class);

                    HttpSession httpSession = request.getSession(true);
                    httpSession.setAttribute("signup_session", httpSession);

                    RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
                    if(requestDispatcher!= null)
                        requestDispatcher.forward(request, response);
                }
                else
                    response.sendRedirect("signup.jsp");
            }
            else
            {
                response.sendRedirect("signup.jsp");
                JOptionPane.showMessageDialog(null, "دو رمز عبور یکی نیستند");    
            }
        }
        else
        {
            response.sendRedirect("signup.jsp");
            JOptionPane.showMessageDialog(null, "اطلاعات ثبت نام ناکامل است");    
        }
    }
    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
