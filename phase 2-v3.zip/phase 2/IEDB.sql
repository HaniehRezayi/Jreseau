/*
SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.1.13-MariaDB : Database - baharedb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`baharedb` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci */;

USE `baharedb`;

/*Table structure for table `adv` */

DROP TABLE IF EXISTS `adv`;

CREATE TABLE `adv` (
  `ADVID` int(11) NOT NULL AUTO_INCREMENT,
  `KarfarmaID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `salary` int(100) NOT NULL,
  `type` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `skill` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `yrsexprience` int(100) NOT NULL,
  `explain` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`ADVID`),
  KEY `FK_adv` (`KarfarmaID`),
  CONSTRAINT `FK_adv` FOREIGN KEY (`KarfarmaID`) REFERENCES `karfarma` (`KarfarmaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `adv` */

/*Table structure for table `advkarjoo` */

DROP TABLE IF EXISTS `advkarjoo`;

CREATE TABLE `advkarjoo` (
  `ADVID` int(11) DEFAULT NULL,
  `KarjooID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  KEY `FK_advkarjoo1` (`KarjooID`),
  KEY `FK_advkarjoo2` (`ADVID`),
  CONSTRAINT `FK_advkarjoo1` FOREIGN KEY (`KarjooID`) REFERENCES `karjoo` (`KarjooID`),
  CONSTRAINT `FK_advkarjoo2` FOREIGN KEY (`ADVID`) REFERENCES `adv` (`ADVID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `advkarjoo` */

/*Table structure for table `advteam` */

DROP TABLE IF EXISTS `advteam`;

CREATE TABLE `advteam` (
  `ADVID` int(11) DEFAULT NULL,
  `TeamID` int(11) DEFAULT NULL,
  KEY `FK_advteam1` (`TeamID`),
  KEY `FK_advteam` (`ADVID`),
  CONSTRAINT `FK_advteam` FOREIGN KEY (`ADVID`) REFERENCES `adv` (`ADVID`),
  CONSTRAINT `FK_advteam1` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `advteam` */

/*Table structure for table `karfarma` */

DROP TABLE IF EXISTS `karfarma`;

CREATE TABLE `karfarma` (
  `KarfarmaID` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `history` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `manager` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `field` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `officename` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `officephone` int(20) NOT NULL,
  `officemail` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pobox` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`KarfarmaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `karfarma` */

/*Table structure for table `karjoo` */

DROP TABLE IF EXISTS `karjoo`;

CREATE TABLE `karjoo` (
  `KarjooID` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `KarfarmaID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `workplace` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `yrsexprience` int(10) NOT NULL,
  `skype` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `facebook` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `linkedin` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`KarjooID`),
  KEY `FK_karjoo` (`KarfarmaID`),
  CONSTRAINT `FK_karjoo` FOREIGN KEY (`KarfarmaID`) REFERENCES `karfarma` (`KarfarmaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `karjoo` */

/*Table structure for table `membership` */

DROP TABLE IF EXISTS `membership`;

CREATE TABLE `membership` (
  `TeamID` int(11) DEFAULT NULL,
  `KarjooID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  KEY `FK_membership1` (`KarjooID`),
  KEY `FK_membership` (`TeamID`),
  CONSTRAINT `FK_membership` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`),
  CONSTRAINT `FK_membership1` FOREIGN KEY (`KarjooID`) REFERENCES `karjoo` (`KarjooID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `membership` */

/*Table structure for table `project` */

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `ProjectID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `category` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `explain` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `manager` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `person` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`ProjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `project` */

/*Table structure for table `projectkarjoo` */

DROP TABLE IF EXISTS `projectkarjoo`;

CREATE TABLE `projectkarjoo` (
  `ProjectID` int(11) DEFAULT NULL,
  `KarfarmaID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  `KarjooID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  KEY `FK_projectkarjoo` (`ProjectID`),
  KEY `FK_projectkarjoo1` (`KarfarmaID`),
  KEY `FK_projectkarjoo2` (`KarjooID`),
  CONSTRAINT `FK_projectkarjoo` FOREIGN KEY (`ProjectID`) REFERENCES `project` (`ProjectID`),
  CONSTRAINT `FK_projectkarjoo1` FOREIGN KEY (`KarfarmaID`) REFERENCES `karfarma` (`KarfarmaID`),
  CONSTRAINT `FK_projectkarjoo2` FOREIGN KEY (`KarjooID`) REFERENCES `karjoo` (`KarjooID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `projectkarjoo` */

/*Table structure for table `projectteam` */

DROP TABLE IF EXISTS `projectteam`;

CREATE TABLE `projectteam` (
  `ProjectID` int(11) DEFAULT NULL,
  `KarfarmaID` varchar(40) COLLATE utf8_persian_ci DEFAULT NULL,
  `TeamID` int(11) DEFAULT NULL,
  KEY `FK_projectteam` (`TeamID`),
  KEY `FK_projectteam1` (`ProjectID`),
  KEY `FK_projectteam2` (`KarfarmaID`),
  CONSTRAINT `FK_projectteam` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`),
  CONSTRAINT `FK_projectteam1` FOREIGN KEY (`ProjectID`) REFERENCES `project` (`ProjectID`),
  CONSTRAINT `FK_projectteam2` FOREIGN KEY (`KarfarmaID`) REFERENCES `karfarma` (`KarfarmaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `projectteam` */

/*Table structure for table `team` */

DROP TABLE IF EXISTS `team`;

CREATE TABLE `team` (
  `TeamID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `phone` int(20) NOT NULL,
  `workfield` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`TeamID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

/*Data for the table `team` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
